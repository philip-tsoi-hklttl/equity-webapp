<?php
require ('vendor/autoload.php');
$dotenv = Dotenv\Dotenv::createImmutable(__DIR__);
$dotenv->load();
//echo $_ENV['LTT_TEST_ENV'];

DEFINE("DEBUG", true); //true or false

DEFINE("MYSQL_HOST", $_ENV['MYSQL_HOST']);
DEFINE("MYSQL_PORT", $_ENV['MYSQL_PORT']);
DEFINE("MYSQL_USERNAME", $_ENV['MYSQL_USERNAME']);
DEFINE("MYSQL_PASSWORD", $_ENV['MYSQL_PASSWORD']);
DEFINE("MYSQL_DATABASE", $_ENV['MYSQL_DATABASE']);
DEFINE("MYSQL_CHARSET", $_ENV['MYSQL_CHARSET']);

DEFINE("SF_CLIENT_ID", $_ENV['SF_CLIENT_ID']);
DEFINE("SF_CLIENT_SECRET", $_ENV['SF_CLIENT_SECRET']);
DEFINE("SF_USERNAME", $_ENV['SF_USERNAME']);
DEFINE("SF_PASSWORD", $_ENV['SF_PASSWORD']);
DEFINE("SF_SECURITY", $_ENV['SF_SECURITY']);
DEFINE("SF_API_VERSION", $_ENV['SF_API_VERSION']);
//DEFINE("SF_SECURITY", "ajaDzZLV43fg36DLJ9yMYj3S7");



$sfobj = array(
    'JB' => array(
        'title' => "Job__c",
        'field' => array("Id", "Name", "CompanyName__c", "Product__c", "CS_Checked__c", "Client_ID__c", "Job_No__c"),
        'datatype' => array("VARCHAR(255)", "VARCHAR(255)", "VARCHAR(255)", "VARCHAR(255)", "VARCHAR(255)", "VARCHAR(255)", "VARCHAR(255)"),
    ),
    'JI' => array(
        'title' => "Job_Item__c",
        'field' => array("Id", "Name", "Bulk_Date__c", "Job__c", "Job_No__c", "Product_Family__c", "Product_Name__c", "Sign_Off__c"),
        'datatype' => array("VARCHAR(255)", "VARCHAR(255)", "VARCHAR(255)", "VARCHAR(255)", "VARCHAR(255)", "TEXT", "TEXT", "VARCHAR(255)"),
    ),
);


//MYSQL PDO CONNECTION
$pdo = new \PDO("mysql:host=".MYSQL_HOST.";dbname=".MYSQL_DATABASE.";charset=".MYSQL_CHARSET.";port=".MYSQL_PORT, 
    MYSQL_USERNAME, 
    MYSQL_PASSWORD, 
    [
        \PDO::ATTR_ERRMODE            => \PDO::ERRMODE_EXCEPTION,
        \PDO::ATTR_DEFAULT_FETCH_MODE => \PDO::FETCH_ASSOC,
        \PDO::ATTR_EMULATE_PREPARES   => false,
    ]
);